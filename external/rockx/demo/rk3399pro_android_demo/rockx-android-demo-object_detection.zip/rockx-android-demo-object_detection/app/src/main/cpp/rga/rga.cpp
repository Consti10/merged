#include <cstring>
#include <unistd.h>
#include <cstdio>
#include "rga.h"
#include "drmrga.h"
#include "graphics-base.h"
#include "RgaApi.h"

#include <android/log.h>
#include <fcntl.h>

#define ALOGI(...) __android_log_print(ANDROID_LOG_INFO, "rga", ##__VA_ARGS__);
#define ALOGE(...) __android_log_print(ANDROID_LOG_ERROR, "rga", ##__VA_ARGS__);

int sina_table[360] = {
	0,	 1144,	 2287,	 3430,	 4572,	 5712,	 6850,	 7987,	 9121,	10252,
	11380,	12505,	13626,	14742,	15855,	16962,	18064,	19161,	20252,	21336,
	22415,	23486,	24550,	25607,	26656,	27697,	28729,	29753,	30767,	31772,
	32768,	33754,	34729,	35693,	36647,	37590,	38521,	39441,	40348,	41243,
	42126,	42995,	43852,	44695,	45525,	46341,	47143,	47930,	48703,	49461,
	50203,	50931,	51643,	52339,	53020,	53684,	54332,	54963,	55578,	56175,
	56756,	57319,	57865,	58393,	58903,	59396,	59870,	60326,	60764,	61183,
	61584,	61966,	62328,	62672,	62997,	63303,	63589,	63856,	64104,	64332,
	64540,	64729,	64898,	65048,	65177,	65287,	65376,	65446,	65496,	65526,
	65536,	65526,	65496,	65446,	65376,	65287,	65177,	65048,	64898,	64729,
	64540,	64332,	64104,	63856,	63589,	63303,	62997,	62672,	62328,	61966,
	61584,	61183,	60764,	60326,	59870,	59396,	58903,	58393,	57865,	57319,
	56756,	56175,	55578,	54963,	54332,	53684,	53020,	52339,	51643,	50931,
	50203,	49461,	48703,	47930,	47143,	46341,	45525,	44695,	43852,	42995,
	42126,	41243,	40348,	39441,	38521,	37590,	36647,	35693,	34729,	33754,
	32768,	31772,	30767,	29753,	28729,	27697,	26656,	25607,	24550,	23486,
	22415,	21336,	20252,	19161,	18064,	16962,	15855,	14742,	13626,	12505,
	11380,	10252,	 9121,	 7987,	 6850,	 5712,	 4572,	 3430,	 2287,	 1144,
	0,	-1144,	-2287,	-3430,	-4572,	-5712,	-6850,	-7987,	-9121, -10252,
	-11380, -12505, -13626, -14742, -15855, -16962, -18064, -19161, -20252, -21336,
	-22415, -23486, -24550, -25607, -26656, -27697, -28729, -29753, -30767, -31772,
	-32768, -33754, -34729, -35693, -36647, -37590, -38521, -39441, -40348, -41243,
	-42126, -42995, -43852, -44695, -45525, -46341, -47143, -47930, -48703, -49461,
	-50203, -50931, -51643, -52339, -53020, -53684, -54332, -54963, -55578, -56175,
	-56756, -57319, -57865, -58393, -58903, -59396, -59870, -60326, -60764, -61183,
	-61584, -61966, -62328, -62672, -62997, -63303, -63589, -63856, -64104, -64332,
	-64540, -64729, -64898, -65048, -65177, -65287, -65376, -65446, -65496, -65526,
	-65536, -65526, -65496, -65446, -65376, -65287, -65177, -65048, -64898, -64729,
	-64540, -64332, -64104, -63856, -63589, -63303, -62997, -62672, -62328, -61966,
	-61584, -61183, -60764, -60326, -59870, -59396, -58903, -58393, -57865, -57319,
	-56756, -56175, -55578, -54963, -54332, -53684, -53020, -52339, -51643, -50931,
	-50203, -49461, -48703, -47930, -47143, -46341, -45525, -44695, -43852, -42995,
	-42126, -41243, -40348, -39441, -38521, -37590, -36647, -35693, -34729, -33754,
	-32768, -31772, -30767, -29753, -28729, -27697, -26656, -25607, -24550, -23486,
	-22415, -21336, -20252, -19161, -18064, -16962, -15855, -14742, -13626, -12505,
	-11380, -10252, -9121,	 -7987,  -6850,  -5712,  -4572,  -3430,  -2287,  -1144
};
int cosa_table[360] = {
	65536,	65526,	65496,	65446,	65376,	65287,	65177,	65048,	64898,	64729,
	64540,	64332,	64104,	63856,	63589,	63303,	62997,	62672,	62328,	61966,
	61584,	61183,	60764,	60326,	59870,	59396,	58903,	58393,	57865,	57319,
	56756,	56175,	55578,	54963,	54332,	53684,	53020,	52339,	51643,	50931,
	50203,	49461,	48703,	47930,	47143,	46341,	45525,	44695,	43852,	42995,
	42126,	41243,	40348,	39441,	38521,	37590,	36647,	35693,	34729,	33754,
	32768,	31772,	30767,	29753,	28729,	27697,	26656,	25607,	24550,	23486,
	22415,	21336,	20252,	19161,	18064,	16962,	15855,	14742,	13626,	12505,
	11380,	10252,	 9121,	 7987,	 6850,	 5712,	 4572,	 3430,	 2287,	 1144,
	0,	-1144,	-2287,	-3430,	-4572,	-5712,	-6850,	-7987,	-9121, -10252,
	-11380, -12505, -13626, -14742, -15855, -16962, -18064, -19161, -20252, -21336,
	-22415, -23486, -24550, -25607, -26656, -27697, -28729, -29753, -30767, -31772,
	-32768, -33754, -34729, -35693, -36647, -37590, -38521, -39441, -40348, -41243,
	-42126, -42995, -43852, -44695, -45525, -46341, -47143, -47930, -48703, -49461,
	-50203, -50931, -51643, -52339, -53020, -53684, -54332, -54963, -55578, -56175,
	-56756, -57319, -57865, -58393, -58903, -59396, -59870, -60326, -60764, -61183,
	-61584, -61966, -62328, -62672, -62997, -63303, -63589, -63856, -64104, -64332,
	-64540, -64729, -64898, -65048, -65177, -65287, -65376, -65446, -65496, -65526,
	-65536, -65526, -65496, -65446, -65376, -65287, -65177, -65048, -64898, -64729,
	-64540, -64332, -64104, -63856, -63589, -63303, -62997, -62672, -62328, -61966,
	-61584, -61183, -60764, -60326, -59870, -59396, -58903, -58393, -57865, -57319,
	-56756, -56175, -55578, -54963, -54332, -53684, -53020, -52339, -51643, -50931,
	-50203, -49461, -48703, -47930, -47143, -46341, -45525, -44695, -43852, -42995,
	-42126, -41243, -40348, -39441, -38521, -37590, -36647, -35693, -34729, -33754,
	-32768, -31772, -30767, -29753, -28729, -27697, -26656, -25607, -24550, -23486,
	-22415, -21336, -20252, -19161, -18064, -16962, -15855, -14742, -13626, -12505,
	-11380, -10252,  -9121,  -7987,  -6850,  -5712,  -4572,  -3430,  -2287,  -1144,
	0,	 1144,	 2287,	 3430,	 4572,	 5712,	 6850,	 7987,	 9121,	10252,
	11380,	12505,	13626,	14742,	15855,	16962,	18064,	19161,	20252,	21336,
	22415,	23486,	24550,	25607,	26656,	27697,	28729,	29753,	30767,	31772,
	32768,	33754,	34729,	35693,	36647,	37590,	38521,	39441,	40348,	41243,
	42126,	42995,	43852,	44695,	45525,	46341,	47143,	47930,	48703,	49461,
	50203,	50931,	51643,	52339,	53020,	53684,	54332,	54963,	55578,	56175,
	56756,	57319,	57865,	58393,	58903,	59396,	59870,	60326,	60764,	61183,
	61584,	61966,	62328,	62672,	62997,	63303,	63589,	63856,	64104,	64332,
	64540,	64729,	64898,	65048,	65177,	65287,	65376,	65446,	65496,	65526
};

int rgafd  = -1;

// 0/near  1/bilnear  2/bicubic
// 0/copy 1/rotate_scale 2/x_mirror 3/y_mirror
// rotate angle
// dither en flag
// AA flag
int NormalRgaSetBitbltMode(struct rga_req *msg,
		unsigned char scale_mode,  unsigned char rotate_mode,
		unsigned int  angle,	   unsigned int  dither_en,
		unsigned int  AA_en,	   unsigned int  yuv2rgb_mode)
{
	unsigned int alpha_mode;
	msg->render_mode = bitblt_mode;

	msg->scale_mode = scale_mode;
	msg->rotate_mode = rotate_mode;

	msg->sina = sina_table[angle];
	msg->cosa = cosa_table[angle];

	msg->yuv2rgb_mode = yuv2rgb_mode;

	msg->alpha_rop_flag |= ((AA_en << 7) & 0x80);

	alpha_mode = msg->alpha_rop_mode & 3;
	if(rotate_mode == BB_ROTATE)
	{
		if (AA_en == ENABLE)
		{
			if ((msg->alpha_rop_flag & 0x3) == 0x1)
			{
				if (alpha_mode == 0)
				{
					msg->alpha_rop_mode = 0x2;
				}
				else if (alpha_mode == 1)
				{
					msg->alpha_rop_mode = 0x1;
				}
			}
			else
			{
				msg->alpha_rop_flag |= 1;
				msg->alpha_rop_mode = 1;
			}
		}
	}

	if (msg->src_trans_mode)
		msg->scale_mode = 0;

	msg->alpha_rop_flag |= (dither_en << 5);

	return 0;
}

#if defined(__arm64__) || defined(__aarch64__)
int NormalRgaMmuInfo(struct rga_req *msg,
                     unsigned char  mmu_en,	 unsigned char	src_flush,
                     unsigned char  dst_flush,unsigned char	cmd_flush,
                     unsigned long base_addr, unsigned char	page_size)
#else
int NormalRgaMmuInfo(struct rga_req *msg,
		unsigned char  mmu_en,	 unsigned char	src_flush,
		unsigned char  dst_flush,unsigned char	cmd_flush,
		unsigned int base_addr,  unsigned char	page_size)
#endif
{
    msg->mmu_info.mmu_en	= mmu_en;
    msg->mmu_info.base_addr = base_addr;
    msg->mmu_info.mmu_flag	= ((page_size & 0x3) << 4) |
                                ((cmd_flush & 0x1) << 3) |
                                ((dst_flush & 0x1) << 2) |
                                ((src_flush & 0x1) << 1) | mmu_en;
    return 1;
}

int NormalRgaMmuFlag(struct rga_req *msg,
                     int  src_mmu_en,   int  dst_mmu_en)
{
    if (src_mmu_en || dst_mmu_en)
        msg->mmu_info.mmu_flag |= (0x1 << 31);

    if (src_mmu_en)
        msg->mmu_info.mmu_flag |= (0x1 << 8);

    if (dst_mmu_en)
        msg->mmu_info.mmu_flag |= (0x1 << 10);

    return 1;
}

int NormalRgaSetDstActiveInfo(struct rga_req *req,
                              unsigned int width, unsigned int height,
                              unsigned int x_off, unsigned int y_off)
{
    req->dst.act_w = width;
    req->dst.act_h = height;
    req->dst.x_offset = x_off;
    req->dst.y_offset = y_off;

    return 1;
}


int NormalRgaSetSrcActiveInfo(struct rga_req *req,
                              unsigned int width, unsigned int height,
                              unsigned int x_off, unsigned int y_off)
{
    req->src.act_w = width;
    req->src.act_h = height;
    req->src.x_offset = x_off;
    req->src.y_offset = y_off;

    return 1;
}

#if defined(__arm64__) || defined(__aarch64__)
int NormalRgaSetDstVirtualInfo(struct rga_req *msg,
                               unsigned long yrgb_addr,unsigned long uv_addr,unsigned long v_addr,
                               unsigned int  vir_w,	unsigned int vir_h,
                               RECT		  *clip,	unsigned char format, unsigned char a_swap_en)
#else
int NormalRgaSetDstVirtualInfo(struct rga_req *msg,
		unsigned int yrgb_addr,unsigned int uv_addr,  unsigned int v_addr,
		unsigned int vir_w,    unsigned int vir_h,
		RECT		   *clip,  unsigned char  format, unsigned char a_swap_en)
#endif
{
    msg->dst.yrgb_addr = yrgb_addr;
    msg->dst.uv_addr  = uv_addr;
    msg->dst.v_addr   = v_addr;
    msg->dst.vir_w = vir_w;
    msg->dst.vir_h = vir_h;
    msg->dst.format = format;

    msg->clip.xmin = clip->xmin;
    msg->clip.xmax = clip->xmax;
    msg->clip.ymin = clip->ymin;
    msg->clip.ymax = clip->ymax;

    msg->dst.alpha_swap |= (a_swap_en & 1);

    return 1;
}

#if defined(__arm64__) || defined(__aarch64__)
int NormalRgaSetSrcVirtualInfo(struct rga_req *req,
                               unsigned long yrgb_addr,unsigned long uv_addr,unsigned long v_addr,
                               unsigned int vir_w ,unsigned int vir_h, unsigned char format,
                               unsigned char a_swap_en)
#else
int NormalRgaSetSrcVirtualInfo(struct rga_req *req,
        unsigned int yrgb_addr, unsigned int uv_addr,unsigned int v_addr,
        unsigned int vir_w, unsigned int vir_h, unsigned char format,
        unsigned char a_swap_en)
#endif
{
    req->src.yrgb_addr = yrgb_addr;
    req->src.uv_addr  = uv_addr;
    req->src.v_addr   = v_addr;
    req->src.vir_w = vir_w;
    req->src.vir_h = vir_h;
    req->src.format = format;
    req->src.alpha_swap |= (a_swap_en & 1);

    return 1;
}

int RkRgaGetRgaFormat(int format)
{
    switch (format)
    {
        case HAL_PIXEL_FORMAT_RGB_565:
            return RK_FORMAT_RGB_565;
        case HAL_PIXEL_FORMAT_RGB_888:
            return RK_FORMAT_RGB_888;
        case HAL_PIXEL_FORMAT_RGBA_8888:
            return RK_FORMAT_RGBA_8888;
        case HAL_PIXEL_FORMAT_RGBX_8888:
            return RK_FORMAT_RGBX_8888;
        case HAL_PIXEL_FORMAT_BGRA_8888:
            return RK_FORMAT_BGRA_8888;
        case HAL_PIXEL_FORMAT_YCRCB_420_SP:
            return RK_FORMAT_YCrCb_420_SP;
        case HAL_PIXEL_FORMAT_YCrCb_NV12:
            return RK_FORMAT_YCbCr_420_SP;
        case HAL_PIXEL_FORMAT_YCrCb_NV12_VIDEO:
            return RK_FORMAT_YCbCr_420_SP;
        case HAL_PIXEL_FORMAT_YCrCb_NV12_10:
            return RK_FORMAT_YCbCr_420_SP_10B; //0x20
        default:
            ALOGE("Is unsupport format now,please fix");
            return -1;
    }
}


int RgaBlit(rga_info *src,rga_info *dst, rga_info_t *src1)
{
    struct rga_req rgaReg;
    int srcVirW,srcVirH,srcActW,srcActH,srcXPos,srcYPos;
    int dstVirW,dstVirH,dstActW,dstActH,dstXPos,dstYPos;
    void *srcBuf = NULL;
    void *dstBuf = NULL;
    rga_rect_t relSrcRect,relDstRect;
    RECT clip;
    int scaleMode,rotation,rotateMode,orientation;
    int stretch = 0;
    float hScale = 1;
    float vScale = 1;

    memcpy(&relSrcRect, &src->rect, sizeof(rga_rect_t));
    memcpy(&relDstRect, &dst->rect, sizeof(rga_rect_t));

    rotation = src->rotation;

    srcVirW = relSrcRect.wstride;
    srcVirH = relSrcRect.hstride;
    srcXPos = relSrcRect.xoffset;
    srcYPos = relSrcRect.yoffset;
    srcActW = relSrcRect.width;
    srcActH = relSrcRect.height;

    dstVirW = relDstRect.wstride;
    dstVirH = relDstRect.height;
    dstXPos = relDstRect.xoffset;
    dstYPos = relDstRect.yoffset;
    dstActW = relDstRect.width;
    dstActH = relDstRect.height;

    srcBuf = src->virAddr;
    dstBuf = dst->virAddr;
    clip.xmin = 0;
    clip.xmax = dstVirW - 1;
    clip.ymin = 0;
    clip.ymax = dstVirH - 1;


    switch (rotation) {
        case HAL_TRANSFORM_FLIP_H:
            orientation = 0;
            rotateMode = 2;
            break;
        case HAL_TRANSFORM_FLIP_V:
            orientation = 0;
            rotateMode = 3;
            break;
        case HAL_TRANSFORM_ROT_90:
            orientation = 90;
            rotateMode = 1;
            break;
        case HAL_TRANSFORM_ROT_180:
            orientation = 180;
            rotateMode = 1;
            break;
        case HAL_TRANSFORM_ROT_270:
            orientation = 270;
            rotateMode = 1;
            break;
        default:
            orientation = 0;
            rotateMode = stretch;
            break;
    }

    hScale = (float) relSrcRect.width / relDstRect.width;
    vScale = (float) relSrcRect.height / relDstRect.height;
    if (rotation == HAL_TRANSFORM_ROT_90 || rotation == HAL_TRANSFORM_ROT_270) {
        hScale = (float) relSrcRect.width / relDstRect.height;
        vScale = (float) relSrcRect.height / relDstRect.width;
    }

    scaleMode = 0;
    stretch = (hScale != 1.0f) || (vScale != 1.0f);
    /* scale up use bicubic */
    if (hScale < 1 || vScale < 1) {
        scaleMode = 2;
        if ((src->format == HAL_PIXEL_FORMAT_RGBA_8888 ||
             src->format == HAL_PIXEL_FORMAT_BGRA_8888)) {
            scaleMode = 0;     //  force change scale_mode to 0 ,for rga not support
        }
    }

    memset(&rgaReg, 0, sizeof(struct rga_req));

    NormalRgaSetSrcVirtualInfo(&rgaReg,0,
                               (unsigned long)srcBuf,
                               (unsigned long)srcBuf + srcVirW * srcVirH,
                               srcVirW, srcVirH,
                               RkRgaGetRgaFormat(relSrcRect.format),0);

    NormalRgaSetDstVirtualInfo(&rgaReg, 0,
                               (unsigned long)dstBuf,
                               (unsigned long)dstBuf + dstVirW * dstVirH,
                               dstVirW, dstVirH, &clip,
                               RkRgaGetRgaFormat(relDstRect.format),0);

    NormalRgaSetSrcActiveInfo(&rgaReg, srcActW, srcActH, srcXPos, srcYPos);
    NormalRgaSetDstActiveInfo(&rgaReg, dstActW, dstActH, dstXPos, dstYPos);

    NormalRgaSetBitbltMode(&rgaReg, scaleMode, rotateMode, orientation,
            0, 0, 0);

    NormalRgaMmuInfo(&rgaReg, 1, 0, 0, 0, 0, 2);
    NormalRgaMmuFlag(&rgaReg, 1, 1);

    rgaReg.yuv2rgb_mode |= 0x1 << 0;

    if(ioctl(rgafd, RGA_BLIT_SYNC, &rgaReg)) {
        ALOGE(" %s(%d) RGA_BLIT fail: %s",__FUNCTION__, __LINE__,strerror(errno));
    }
    return 0;

}

int RgaInit(void **ctx) {

    if (rgafd < 0 ) {
        rgafd = open("/dev/rga", O_RDWR, 0);
    }

    if (rgafd < 0) {
        ALOGE("open /dev/rga fail");
        return -1;
    }

    return 0;
}

int  RgaDeInit(void *ctx) {

    if (rgafd != -1) {
        close(rgafd);
        rgafd = -1;
    }

    return 0;
}