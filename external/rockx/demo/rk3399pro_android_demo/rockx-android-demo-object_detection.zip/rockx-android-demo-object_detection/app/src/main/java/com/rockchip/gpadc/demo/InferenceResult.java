package com.rockchip.gpadc.demo;

import android.content.res.AssetManager;
import android.graphics.RectF;

import java.io.IOException;
import java.util.ArrayList;

import static java.lang.System.arraycopy;

public class InferenceResult {

    OutputBuffer mOutputBuffer;
    ArrayList<DetectObject> detectObject = null;
    private boolean mIsVaild = false;   //是否需要重新计算

    public void init(AssetManager assetManager) throws IOException {
        mOutputBuffer = new OutputBuffer();
    }

    public void reset() {
        if (detectObject != null) {
            detectObject.clear();
            mIsVaild = true;
        }
    }

    public synchronized void setResult(ArrayList<DetectObject> faces) {
        this.detectObject = faces;
    }

    public synchronized ArrayList<DetectObject> getResult() {
        return detectObject;
    }

    public static class OutputBuffer {
        public float[] mLocations;
        public float[] mClasses;
    }

}
