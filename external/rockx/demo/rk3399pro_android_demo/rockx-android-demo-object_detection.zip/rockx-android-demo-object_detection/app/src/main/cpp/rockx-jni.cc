#include "rockx.h"
#include "log.h"
#include "jni.h"
#include <unistd.h>
#include <string.h>
#include <cstdlib>

/*************************************************************************
                        comman function
**************************************************************************/
static char* jstringToChar(JNIEnv* env, jstring jstr) {
    char* rtn = NULL;
    jclass clsstring = env->FindClass("java/lang/String");
    jstring strencode = env->NewStringUTF("utf-8");
    jmethodID mid = env->GetMethodID(clsstring, "getBytes", "(Ljava/lang/String;)[B");
    jbyteArray barr = (jbyteArray) env->CallObjectMethod(jstr, mid, strencode);
    jsize alen = env->GetArrayLength(barr);
    jbyte* ba = env->GetByteArrayElements(barr, JNI_FALSE);

    if (alen > 0) {
        rtn = new char[alen + 1];
        memcpy(rtn, ba, alen);
        rtn[alen] = 0;
    }
    env->ReleaseByteArrayElements(barr, ba, 0);
    return rtn;
}

jobject object_c2j(JNIEnv *env, rockx_object_t *detect_object, int inWidth, int inHeight) {
    jclass cls_DetectObject = env->FindClass("com/rockchip/gpadc/demo/DetectObject");
    jmethodID DetectObject_construct = env->GetMethodID(cls_DetectObject, "<init>", "(FFFFFF)V");

    jvalue * args = (jvalue*)malloc(6*sizeof(jvalue));
    args[0].f = (float)detect_object->box.left / inWidth;
    args[1].f = (float)detect_object->box.top / inHeight;
    args[2].f = (float)detect_object->box.right / inWidth;
    args[3].f = (float)detect_object->box.bottom / inHeight;
    args[4].f = detect_object->score;
    args[5].f = (float)detect_object->cls_idx;
    LOGI("(%f %f %f %f) %f %f", args[0].f, args[1].f, args[2].f, args[3].f, args[4].f, args[5].f)
    LOGI("%d", detect_object->cls_idx)
    jobject objectj = env->NewObjectA(cls_DetectObject, DetectObject_construct, args);
    if (args != nullptr) {
        free(args);
    }
    return objectj;
}


int object_array_c2j(JNIEnv *env, rockx_object_array_t *detect_object_array, jobject detectObjectList, int inWidth, int inHeight) {
    jclass cls_ArrayList = env->GetObjectClass(detectObjectList);
    jmethodID ArrayList_add = env->GetMethodID(cls_ArrayList, "add", "(Ljava/lang/Object;)Z");

    for (int i = 0; i < detect_object_array->count; i++) {
        jobject detectObject = object_c2j(env, &(detect_object_array->object[i]), inWidth, inHeight);
        env->CallBooleanMethod(detectObjectList, ArrayList_add, detectObject);
    }
    return 0;
}

/*************************************************************************
                        rockx jni api
**************************************************************************/
extern "C"
JNIEXPORT jlong JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1create_1rockx_1module
        (JNIEnv *env, jobject obj, jstring modelPath, jint module)
{
    rockx_ret_t ret;

    rockx_handle_t handle;

    char *model_path = jstringToChar(env, modelPath);

    rockx_config_t rockx_configs;
    memset(&rockx_configs, 0, sizeof(rockx_config_t));

    LOGI("rockx_add_config ROCKX_CONFIG_DATA_PATH=%s\n", model_path);

    rockx_add_config(&rockx_configs, (char *)ROCKX_CONFIG_DATA_PATH, model_path);

    ret = rockx_create(&handle, (rockx_module_t)module, &rockx_configs, sizeof(rockx_config_t));
    if (ret != ROCKX_RET_SUCCESS) {
        LOGI("init rockx module %d error %d\n", module, ret);
        return ret;
    }

    return (jlong)handle;
}

extern "C"
JNIEXPORT void JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1destroy_1rockx_1module
		(JNIEnv *env, jobject obj, jlong handle) {
	rockx_destroy((rockx_handle_t)handle);
}

/*************************************************************************
                        rockx face jni api
**************************************************************************/
extern "C"
JNIEXPORT jint JNICALL Java_com_rockchip_gpadc_demo_rockx_RockX_native_1detect
        (JNIEnv *env, jobject obj, jlong handle, jbyteArray inData, jint inWidth, jint inHeight, jint inPixelFmt,
            jobject faceList) {

  	jboolean inputCopy = JNI_FALSE;
  	jbyte* in_data = env->GetByteArrayElements(inData, &inputCopy);

    // initial rockx_image_t variable
    rockx_image_t input_image;
    input_image.width = inWidth;
    input_image.height = inHeight;
    input_image.data = (unsigned char *)in_data;
    input_image.pixel_format = (rockx_pixel_format)inPixelFmt;

    // create rockx_face_array_t for store result
    rockx_object_array_t face_array;
    memset(&face_array, 0, sizeof(rockx_object_array_t));

    // detect face
    rockx_ret_t ret = rockx_object_detect((rockx_handle_t)handle, &input_image, &face_array, nullptr);
    if (ret != ROCKX_RET_SUCCESS) {
        printf("rockx_face_detect error %d\n", ret);
        return -1;
    }

    object_array_c2j(env, &face_array, faceList, inWidth, inHeight);

	env->ReleaseByteArrayElements(inData, in_data, JNI_ABORT);
    inData=nullptr;
	return 0;
}