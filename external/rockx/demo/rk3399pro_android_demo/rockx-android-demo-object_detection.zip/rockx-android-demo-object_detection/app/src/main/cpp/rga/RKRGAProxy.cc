//
// Created by randall on 19-2-14.
//

#include "RKRGAProxy.h"
#include <errno.h>
#include <string.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <android/log.h>
#include <sys/time.h>

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "rgaproxy", ##__VA_ARGS__);
#define LOGE(...) __android_log_print(ANDROID_LOG_INFO, "rgaproxy", ##__VA_ARGS__);

RKRGAProxy::RKRGAProxy(): mSupportRga(false), mContext(NULL) {
    RkRgaInit();
}

RKRGAProxy::~RKRGAProxy() {
    RgaDeInit(mContext);
}

int RKRGAProxy::RkRgaInit() {
    int ret = 0;

    ret = RgaInit(&mContext);
    if(ret == 0)
        mSupportRga = true;
    else
        mSupportRga = false;

    return 0;
}

int RKRGAProxy::convert(void *src, int srcWidth, int srcHeight, int srcFmt,
             void *dst, int dstWidth, int dstHeight, int dstFmt, int flip) {
    int ret = 0;

    rga_info_t rgasrc;
    rga_info_t rgadst;

    memset(&rgasrc, 0, sizeof(rga_info_t));
    rgasrc.fd = -1;
    rgasrc.mmuFlag = 1;
    rgasrc.virAddr = src;

    memset(&rgadst, 0, sizeof(rga_info_t));
    rgadst.fd = -1;
    rgadst.mmuFlag = 1;
    rgadst.virAddr = dst;

    rga_set_rect(&rgasrc.rect, 0,0, srcWidth, srcHeight, srcWidth, srcHeight, srcFmt);
    rga_set_rect(&rgadst.rect, 0,0, dstWidth, dstHeight, dstWidth, dstHeight, dstFmt);

    if (flip != -1) {
        rgasrc.rotation = flip;
    }

    timeval oldTime,newTime;
    gettimeofday(&oldTime, NULL);

    ret = RgaBlit(&rgasrc, &rgadst, NULL);

    if (ret != 0) {
        LOGE("_RgaBlit fail!\n")
    }

    gettimeofday(&newTime, NULL);

//    LOGI("RGA convert time:%0.2f ms\n", (newTime.tv_sec-oldTime.tv_sec)*1000 + ((newTime.tv_usec-oldTime.tv_usec)/1000.0));

    return 0;
}
