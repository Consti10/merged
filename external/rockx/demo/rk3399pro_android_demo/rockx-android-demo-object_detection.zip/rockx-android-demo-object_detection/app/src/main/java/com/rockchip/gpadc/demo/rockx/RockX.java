package com.rockchip.gpadc.demo.rockx;

import android.content.Context;
import android.content.res.AssetManager;
import android.util.Log;

import com.rockchip.gpadc.demo.DetectObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class RockX {
    public static final String TAG = "rockx";

    private static final int ROCKX_MODULE_FACE_DETECTION = 1;
    private static final int ROCKX_MODULE_FACE_LANDMARK_68 = 2;
    private static final int ROCKX_MODULE_FACE_RECOGITION = 3;
    private static final int ROCKX_MODULE_FACE_ANALYZE = 4;
    private static final int ROCKX_MODULE_OBJECT_DETECTION = 5;
    private static final int ROCKX_MODULE_POSE_BODY = 6;
    private static final int ROCKX_MODULE_POSE_FINGER_21 = 7;
    private static final int ROCKX_MODULE_FACE_LANDMARK_5 = 8;
    private static final int ROCKX_MODULE_HEAD_DETECTION = 9;
    private static final int ROCKX_MODULE_CARPLATE_DETECTION = 10;
    private static final int ROCKX_MODULE_CARPLATE_ALIGN = 11;
    private static final int ROCKX_MODULE_CARPLATE_RECOG = 12;
    private static final int ROCKX_MODULE_OBJECT_TRACK = 13;
    private static final int ROCKX_MODULE_POSE_FINGER_3 = 14;
    private static final int ROCKX_MODULE_FACE_LIVENESS = 15;

    public static final int ROCKX_PIXEL_FORMAT_GRAY8 = 0;
    public static final int ROCKX_PIXEL_FORMAT_RGB888 = 1;
    public static final int ROCKX_PIXEL_FORMAT_BGR888 = 2;
    public static final int ROCKX_PIXEL_FORMAT_RGBA8888 = 3;
    public static final int ROCKX_PIXEL_FORMAT_BGRA8888 = 4;
    public static final int ROCKX_PIXEL_FORMAT_YUV420P_YU12 = 5;
    public static final int ROCKX_PIXEL_FORMAT_YUV420P_YV12 = 6;
    public static final int ROCKX_PIXEL_FORMAT_YUV420SP_NV12 = 7;
    public static final int ROCKX_PIXEL_FORMAT_YUV420SP_NV21 = 8;

    private String mModelPath;
    private Context mContext;

    private long mRockXFaceDetectionModule;
    private long mRockXFaceLandmark5Module;
    private long mRockXFaceRecognitionModule;
    private long mRockXHeadDetectionModule;
    private long mRockxObecjtDetectionModule;

    public RockX(Context context) {
        mContext = context;
    }
    public void create() {
        mModelPath = installRockxData(mContext);
        mRockxObecjtDetectionModule = native_create_rockx_module(mModelPath, ROCKX_MODULE_OBJECT_DETECTION);
    }

    public String installRockxData(Context context) {
        File rockxDataDir = new File(context.getFilesDir().getAbsolutePath() + "/rockx-data");
        if (rockxDataDir.exists()) {
            Log.d(TAG, String.format("%s already exist", rockxDataDir.getAbsoluteFile()));
            return rockxDataDir.getAbsolutePath();
        }
        Log.d(TAG, String.format("create %s", rockxDataDir.getAbsoluteFile()));
        rockxDataDir.mkdir();
        AssetManager am = context.getAssets();
        try {
            String rockxDataFileList[] = am.list("rockx-data");
            for (String rockxDataFile : rockxDataFileList) {
                Log.d(TAG, String.format("create %s", rockxDataDir + "/" + rockxDataFile));
                InputStream is = am.open("rockx-data/" + rockxDataFile);
                FileOutputStream fos = new FileOutputStream(rockxDataDir + "/" + rockxDataFile);
                byte[] buffer = new byte[1024];
                int byteCount;
                while ((byteCount = is.read(buffer)) != -1) {
                    fos.write(buffer, 0, byteCount);
                }
                fos.flush();
                is.close();
                fos.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return rockxDataDir.getAbsolutePath();
    }

    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        native_destroy_rockx_module(mRockxObecjtDetectionModule);
    }

    public ArrayList<DetectObject> detectObject(byte[] inData, int inWidth, int inHeight, int inPixelFmt) {
        ArrayList<DetectObject> faceList = new ArrayList<>();
        native_detect(mRockxObecjtDetectionModule, inData, inWidth, inHeight, inPixelFmt, faceList);
        return faceList;
    }


    private native long native_create_rockx_module(String modelPath, int module);
    private native void native_destroy_rockx_module(long handle);
    private native int native_detect(long handle, byte[] inData, int inWidth, int inHeight, int inPixelFmt, ArrayList<DetectObject> faceList);


    static {
        System.loadLibrary("rknn4j");
    }
}
